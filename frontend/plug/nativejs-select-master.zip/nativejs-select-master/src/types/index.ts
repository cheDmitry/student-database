export type ObjString = {
  [key in string]: string;
};
