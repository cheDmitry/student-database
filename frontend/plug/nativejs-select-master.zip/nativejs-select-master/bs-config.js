module.exports = {
  watch: true,
  watchOptions: { 
    ignored: ['./src'] 
  },
  server: './',
  startPath: 'devserver/index.html',
  notify: false,
  open: false,
}