module.exports = {
  moduleDirectories: ['node_modules', 'src'],
  verbose: true,
  preset: 'ts-jest',
  snapshotSerializers: ['jest-serializer-html'],
};
